<p>You have received a new message</p>

<p><strong>First Name:</strong> <?php echo e($contact->first_name); ?></p>
<p><strong>Last Name:</strong> <?php echo e($contact->last_name); ?></p>
<p><strong>Email:</strong> <?php echo e($contact->email); ?></p>
<p><strong>Comments:</strong> <?php echo e($contact->comments); ?></p>

<p>Best regards,<br>IqSpark</p>
<?php /**PATH /home/sharhitu/api.iqspark.org/resources/views/emails/contact.blade.php ENDPATH**/ ?>